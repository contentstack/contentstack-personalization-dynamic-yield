const fs = require('fs');
const AWS = require('aws-sdk');
const s3 = new AWS.S3({
  accessKeyId: process.env.ACCESS_KEY,
  secretAccessKey: process.env.SECRET_ACCESS_KEY
});
const { Parser, transforms: { flatten } } = require('json2csv');
const json2csvParser = new Parser({ transforms: [flatten({ separator: '_' })]});
const bucketName = process.env.BUCKET_NAME;

// Upload csv file to s3
async function uploadFile(variations) {
  try {
    // Convert variations from json to csv
    const csv = json2csvParser.parse(variations.hero_banner);

    await writeFile('/tmp/variations.csv', csv);

    const fileData = await readFile('/tmp/variations.csv');

    const params = {
      Bucket: bucketName, // pass your bucket name
      Key: 'variations.csv', // file will be saved as testBucket/contacts.csv
      Body: fileData,
      ACL: "public-read"
    };
    const res = await s3.upload(params).promise();
    console.log('File uploaded on S3 successfully', res.Location);
  }
  catch (error) {
    console.log(error);
  }
};

async function readFile(path) {
  return new Promise((resolve, reject) => {
    fs.readFile(path, 'utf8', function (err, data) {
      if (err) {
        reject(err);
      }
      console.log('Successfully read CSV file');
      resolve(data);
    });
  });
}

async function writeFile(path, csv) {
  return new Promise((resolve, reject) => {
    fs.writeFile(path, csv, (err) => {
      if (err) {
        reject(err);
      }
      console.log('Successfully written in CSV file');
      resolve();
    });
  });
}

exports.handler = async (event) => {
  var body = JSON.parse(event.body);

  console.log('Data', body.data);
  await uploadFile(body.data.entry);

  return;
};
